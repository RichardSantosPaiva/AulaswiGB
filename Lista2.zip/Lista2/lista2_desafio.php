<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Laços de Repetição </h1>
    <h3>Programa para exibi todos os valores entre 1 e um valor informado pelo usuário</h3>
    <a href="../Lista2">Voltar</a>
    <form action="" method="GET">
        <p>Informe um valor maior que 1:</br>
            <input type="text" name="num" /></br>
        </p>
        <p>Selecione o metódo desejado:</p></br>
        <span><input type="radio" name="metodo" value="enquanto">Laço enquanto</span></br>
        <span><input type="radio" name="metodo" value="faca">Laço Faça-enquanto</span></br>
        <span><input type="radio" name="metodo" value="para">Laço Para</span></br>

        <input type="submit" name="exibir" value="Exibir" />
    </form>
</body>
    <?php
    //entrada

    if(isset($_GET['exibir'])) {
        $num = $_GET['num'];
        $metodo = $_GET['metodo'];
        if($num > 1) {

            switch ($metodo) {

                case 'enquanto':
                    echo "<h5>Exibindo valores por While</h5>";
                    $i = 1;
                    while ($i <= $num) {
                        echo "</br>Valor: $i";
                        $i++;
                    } 
                    break;
                case 'faca':
                    echo "<h5>Exibindo valores por Do While</h5>";
                    $i = 1;
                    do {
                        echo"</br>Valor: $i";
                        $i++;
                    } while ($i <= $num);
                    break;
                case 'para':
                    echo "<h5>Exibindo valores por For</h5>";
                    for ($i = 1; $i <= $num; $i++) {
                        echo"</br>Valor: $i";
                    }
                     break;


            }

            /* esse trecho, foi o primeiro trecho de código que fiz antes desse acima
            
            $i =1;
             while ($i <= $num) {
                echo "</br> Valor : $i";
                $i++;
             }*/
        }
        else {
            echo "Favor inserir um valor maior que 1";
        }
    }
    else {
        echo "Aguardando entrada de dados!";

    }
    ?>
</html>
