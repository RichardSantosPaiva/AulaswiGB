<!DOCTYPE_html>
<html lang="pt-BR">
	<head>
		<title>Lista 2 - Exercício 4</title>
		<meta charset="utf-8" />
	</head>
	<?php
		$usuarios[1]["nome"] = "Gerson";
		$usuarios[1]["email"] = "ge@goo.com";
		$usuarios[1]["senha"] = "123456";
		$usuarios[2]["nome"] = "Pedro";
		$usuarios[2]["email"] = "pedr@hm.com";
		$usuarios[2]["senha"] =	"75324";
		$usuarios[3]["nome"] = "Manuel";
		$usuarios[3]["email"] = "manu@goo.com";
		$usuarios[3]["senha"] =	"98765";	
		$usuarios[4]["nome"] = "Madalena";
		$usuarios[4]["email"] = "mada@b.com";
		$usuarios[4]["senha"] = "95126";
		$usuarios[5]["nome"] = "Joana";
		$usuarios[5]["email"] = "jojo@goo.com";
		$usuarios[5]["senha"] = "35742";
		$tamanho = count($usuarios);
	?>	
	<body>
		<h3>Matriz multidimencional de usuários</h3>
		<h4>Exercício 4 - Lista 2</h4>
		<p><a href="http://localhost/lista2">Voltar</a></p>
		
		<form action="" method="GET">
			<p>Informe um valor entre 1 e <?php echo $tamanho; ?> para ser pesquisado: 
				<input type="text" name="indice">
			<br/></p>
			<input type="submit" name="pesquisar" value="Pesquisar">
		</form>
	</body>

	<?php
		//executa somente se clicado em pesquisar
		if (isset ($_GET['pesquisar'])):
		
			//atribuindo variáveis de entrada
			$selec = $_GET['indice'];
			
			//exibir resultado
			if ($selec <= $tamanho && $selec > 0):
				echo "Usuário $selec:<br>";
				echo "Nome: ".$usuarios[$selec]["nome"]."<br>";
				echo "E-mail: ".$usuarios[$selec]["email"]."<br>";
				echo "Senha: ".$usuarios[$selec]["senha"]."<br>";
			else:
				echo "Índice $selec é inválido! Tente novamente";
			endif;
		else:
			echo "<br/>Aguardando selecionar dados!";
		endif;
	?>
</html>
	