<!DOCTYPE_html>
<html lang="pt-BR">
	<head>
		<title>Lista 2 - Exercício 2</title>
		<meta charset="utf-8" />
	</head>
	<?php
		/* Exercicio 1
		elaborado por Gerson Rocco */
		
		//cria o array de cidades
		//atribuindo primeira chave do array como "1"
		$cidades = array (1=>"Barueri","Carapicuíba","Osasco","Cajamar","Stna de Parnaíba");
		
		$cidades[] = "Pirapora";
		$cidades[] = "Mairiporã";
		$cidades[] = "Caieira";
		$cidades[] = "F. Morato";
		$cidades[] = "Jundiaí";
		$tamanho = count($cidades);
	?>
	<body>
		<h3>Matriz unidimencional de cidades</h3>
		<h4>Exercício 2 - Lista 2</h4>
		<p><a href="http://localhost/lista2">Voltar</a></p>
		<form action="" method="GET">
			<p>Informe um valor entre 1 e <?php echo $tamanho; ?> para ser pesquisado: 
				<input type="text" name="indice">
			<br/></p>
			<input type="submit" name="pesquisar" value="Pesquisar">
		</form>
	</body>	
	<?php		
		//executa somente se clicado em pesquisar
		if (isset ($_GET['pesquisar'])):
		
			//atribuindo variáveis de entrada
			$indice = $_GET['indice'];
			
			//exibir resultado
			if ($indice <= $tamanho && $indice > 0)
				echo "A cidade na posição $indice é: ".$cidades[$indice];
			else
				echo "Índice $indice é inválido! Tente novamente";
		else:
			echo "<br/>Aguardando selecionar dados!";
		endif;
	?>
</html>
	