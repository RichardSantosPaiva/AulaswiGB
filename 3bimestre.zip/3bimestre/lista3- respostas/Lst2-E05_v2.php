<!DOCTYPE_html>
<html lang="pt-BR">
	<head>
		<title>Lista 2 - Exercício 5</title>
		<meta charset="utf-8" />
	</head>
	<?php
		echo "<h3>Matriz multidimencional de alunos e notas</h3>";
		echo "<h4>Exercício 5 - Lista 2</h4>";
		echo "<a href='http://localhost/lista3'>Voltar</a>";
		echo "<br/>";
		$alunos[1]["nome"] = "Zezinho";
		$alunos[1]["nota"] = 5;
		$alunos[2]["nome"] = "Huguinho";
		$alunos[2]["nota"] = 8.5;
		$alunos[3]["nome"] = "Luizinho";
		$alunos[3]["nota"] = 3.5;
		$alunos[4]["nome"] = "Joãozinho";
		$alunos[4]["nota"] = 10;
		$alunos[5]["nome"] = "Pedrinho";
		$alunos[5]["nota"] = 9;
		$tamanho = count($alunos);
		echo "<h3>Exibindo lista de dados:</h3><br>";
		//print_r ($alunos)
		echo "<table border=0>";
		echo "<tr>
			<th>Nome</th>
			<th>Nota</th>
			</tr>";
		$i=1;
		while ($i <= $tamanho):
			echo "<tr>
				<td>{$alunos[$i]['nome']}</td>
				<td>{$alunos[$i]['nota']}</td>
				</tr>";
			$i++;
		endwhile;
		echo "</table>";
		?>
</html>
	