<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
 
      <form action="" method="GET">
            <input type="text" name="indice">
            <input type="submit" name="enviar" value="enviar">
      </form>

     
    <?php
        //https://blog.betrybe.com/php/php-array-lenght/ . Sobre array multidimensional.
        if(isset($_GET['enviar'])) {

       /* $usuario = array(array("nome"=>"Richard", "email"=>"richard@gmail.com","senha"=>"123"),array("nome"=>"Julio", "email"=>"julio@gmail.com","senha"=>"321"),array("nome"=>"Larissa", "email"=>"larissa@gmail.com","senha"=>"1s23")
        array("nome"=>"Manuel", "email"=>"manuel@gmail.com","senha"=>"908")) ;*/
        //nome seria como a várial  que armazena o valor é o Richard  codigos//

        $usuario[1]='Nome'=>'Richard';
        $usuario[1]='Email'=> 'richard@gmail.com';
        $usuario[1]='Senha'=>'123';
        
        } 

    ?>
</body>
</html>