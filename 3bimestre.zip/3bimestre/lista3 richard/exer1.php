<html lang="pt-BR">

	<head>
		<meta charset="UTF-8">
		<title>Exercício 1 - 5 cidades</title>
	</head>
	
	<body>
	<?php



		$cidades = array("Barueri","Carapicuíba","Osasco","Cajamar","Stna de Parnaíba");
		$tamanho = count($cidades);

	?>

		<form method="GET">
			<p>Informe um valor entre 1  e <?php echo $tamanho; ?> Para ser pesquisado:
				<input type="number" name="indice">
			<br></p>
		<input type="submit" name="pesquisar" value="pesquisar">
		</form>

		<?php

		if (isset($_GET['pesquisar'])) {

			$indice = $_GET['indice'];

			if ($indice <= $tamanho && $indice > 0){
			echo "A cidade na posição $indice é: ".$cidades[$indice-1];
			}else{
				echo "Índice $indice é inválido! Tente novamente";
			}
			
		} else {
			echo "<br/>Aguardando selecionar dados!";
		}
	?>
	
	</body>
</html>
	