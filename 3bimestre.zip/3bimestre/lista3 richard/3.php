<!DOCTYPE_html>
<html lang="pt-BR">
	<head>
		<title>Lista 2 - Exercício 2</title>
		<meta charset="utf-8" />
	</head>
	<?php
		//criando o array
		$paises["BRA"] = "Brasil";
		$paises["ING"] = "Inglaterra";
		$paises["EUA"] = "Estados Unidos";
	?>
	<body>
		<h3>Matriz unidimencional de três países</h3>
		<h4>Exercício 3 - Lista 2</h4>
		<p><a href="http://localhost/lista2">Voltar</a></p>
		<form action="" method="GET">
			<p>Selecione o país:
				<span><br/><input type="radio" name="pais" value="BRA">Brasil</span>
				<span><br/><input type="radio" name="pais" value="ING">Inglaterra</span>
				<span><br/><input type="radio" name="pais" value="EUA">Estados Unidos</span>
			</P>
			<input type="submit" name="pesquisar" value="Pesquisar">
		</form>
	</body>	
	<?php
		//executa somente se clicado em pesquisar
		if (isset ($_GET['pesquisar'])):

			//atribuindo variáveis de entrada
			$selec = $_GET['pais'];
			//echo $selec;
			//print_r ($paises);
			echo "O país selecionado foi: ".$paises[$selec];
		else:
			echo "<br/>Aguardando selecionar dados!";	
		endif;
	?>
</html>
	