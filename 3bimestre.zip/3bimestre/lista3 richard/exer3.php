<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="GET">

<select name="paises">

  <option value="BRA">Brasil</option>

  <option value="ING">Inglaterra</option>

  <option value="EUA">Estados Unidos</option>    

</select><br>

<input type="submit" value="escolher">

</form>



<?php



if(isset($_GET['paises'])){

$paises = array('BRA'=>'Brasil','ING'=>'Inglaterra','EUA'=>'Estados Unidos');



    echo $paises[$_GET['paises']];

}        

?>
</body>
</html>