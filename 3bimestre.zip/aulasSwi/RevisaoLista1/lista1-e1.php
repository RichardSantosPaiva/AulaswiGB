<!DOCTYPE html>
<html lang="pt-BR">
	<head>
		<title>Lista 1 - exec1</title>
		<meta charset="utf-8" />
	</head>
	<body>
		<h1>Programa para conversão entre milímetro e polegada</h1>
		<h4>Lista 1 - Exercício 1</h4>
		<form action="" method="GET">
			<p>Informe um valor para ser convertido<br/>
				<input type="text" name="valor">
			</p>
			<p>Selecione o tipo de conversão:<br/>
				<span>
					<input type="radio" value="pol" name="conversao">
					Milímetro para polegada
				</span><br/>
				<span>
					<input type="radio" value="mili" name="conversao">
					Polegada para milímetro 
				</span>
			</p>
			<input type="submit" value="Converter" name="converter">
		</form>
	</body>
	<?php
		if (isset($_GET['converter'])) {
			//entrada de dados
			$valor=$_GET['valor'];
			$conversao = $_GET['conversao'];
			
			//processamento de dados
			switch ($conversao) {
				case 'pol':
					$resultado = $valor/25.4;
					$txtUm = 'milímetro';
					$txtDois = 'polegada';
					break;
				case 'mili':
					$resultado = $valor*25.4;
					$txtUm = 'polegada';
					$txtDois = 'milímetro';
					break;
			}
			
			//saída dos dados
			echo "$valor em $txtUm é igual a $resultado $txtDois";	
		}
	?>
</html>
