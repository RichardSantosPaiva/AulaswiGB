<!DOCTYPE_html>
<html lang="pt-BR">
	<head>
		<title>Lista 1 - Exercício 5</title>
		<meta charset="utf-8" />
	</head>
	<body>
		<h3>Calcula a qtd horas, minutos e segundos</h3>
		<h4>Exercício 5</h4>
		<p><a href="http://localhost/lista1">Voltar</a></p>
		<form action="" method="GET">
			<p>Informe em segundos: 
				<input type="text" name="tempo">
			<br/></p>
			<input type="submit" name="calcular" value="Calcular">
		</form>
	</body>	

	<?php
		/* Exercicio 5
		elaborado por Gerson Rocco */
			
		//executa somente se clicado em calcular
		if (isset ($_GET['calcular']))
		{
			//declaração de variáveis
			$tempo = $_GET['tempo'];
			
			//processamento
			$aux = $tempo % 3600;
			$hora = ($tempo - $aux)/3600;
			$segundo = $aux % 60;
			$minuto = ($aux - $segundo)/60;
			
			//resultado e saída
			echo "<br>O periodo de $tempo segundos, corresponde a:";
			echo "<br>$hora hora(s),";
			echo "<br>$minuto minuto(s) e";
			echo "<br>$segundo segundo(s)";
		}
	?>
</html>