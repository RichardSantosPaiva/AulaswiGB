<!DOCTYPE_html>
<html lang="pt-BR">
	<head>
		<title>Lista 1 - Exercício 4</title>
		<meta charset="utf-8" />
	</head>
	<body>
		<h3>Calculadora de Divisão para 2 numeros</h3>
		<h4>Exercício 4</h4>
		<p><a href="http://localhost/lista1">Voltar</a></p>
		<form action="" method="GET">
			<p>Informe o valor do dividendo: 
				<input type="text" name="dividendo">
			<br/></p>
			<p>Informe o valor do divisor: 
				<input type="text" name="divisor">
			<br/></p>
			<input type="submit" name="calcular" value="Calcular">
		</form>
	</body>	

	<?php
		/* Exercicio 6
		elaborado por Gerson Rocco */
		
		//executa somente se clicado em calcular
		if (isset ($_GET['calcular'])):
			//declaração de variáveis
			$dividendo = $_GET['dividendo'];
			$divisor = $_GET['divisor'];
			
			//processamento
			$resto = $dividendo % $divisor;
			$quociente = ($dividendo-$resto)/$divisor;
			
			//resultado e saída
			echo "Dividendo = $dividendo<br>";
			echo "Divisor = $divisor<br>";
			echo "Quociente = $quociente<br>";
			echo "Resto = $resto<br>";
		endif;
	?>
</html>