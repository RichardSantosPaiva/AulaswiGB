<!DOCTYPE_html>
<html lang="pt-BR">
	<head>
		<title>Lista 1 - Exercício 3</title>
		<meta charset="utf-8" />
	</head>
	<body>
		<h3>Programa para calcular as 4 operações básicas</h3>
		<h4>Exercício 3</h4>
		<p><a href="http://localhost/lista1">Voltar</a></p>
		<form action="" method="GET">
			<p>Informe o primeiro valor: 
				<input type="text" name="val1">
			<br/></p>
			<p>Informe o segundo valor: 
				<input type="text" name="val2">
			<br/></p>
			<input type="submit" name="calcular" value="Calcular">
		</form>
	</body>	
	<?php
		/* Exercicio 3
		elaborado por Gerson Rocco */
		
		//executa somente se clicado em calcular
		if (isset ($_GET['calcular']))
		{
			//atribuindo variáveis de entrada
			$val1 = $_GET['val1'];
			$val2 = $_GET['val2'];
			
			//processamento
			$soma = $val1 + $val2;
			$diferenca = $val1 - $val2;
			$produto = $val1 * $val2;
			$quociente = $val1 / $val2;
			//resultado e saída
			echo "Soma de ".$val1." e ".$val2." é igual a $soma<br>";
			echo "Subtração de $val1 e $val2 é igual a $diferenca<br>";
			echo "Multiplicação de $val1 e $val2 é igual a $produto<br>";
			echo "Divisão de $val1 e $val2 é igual a $quociente<br>";
		}
	?>
</html>