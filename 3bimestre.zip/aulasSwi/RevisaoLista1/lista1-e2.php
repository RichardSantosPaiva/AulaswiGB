<!DOCTYPE html>
<html lang="pt-BR">
	<head>
		<title>Lista 1 - exec2</title>
		<meta charset="utf-8" />
	</head>
	<body>
		<h1>Programa para conversão entre graus Celsius e Farenheit</h1>
		<h4>Lista 1 - Exercício 2</h4>
		<form action="" method="GET">
			<p>Informe um valor para ser convertido<br/>
				<input type="text" name="valor">
			</p>
			<p>Selecione o tipo de conversão:<br/>
				<span>
					<input type="radio" value="cel" name="conversao">
					Farenheit para Celsius
				</span><br/>
				<span>
					<input type="radio" value="far" name="conversao">
					Celsius para Farenheit
				</span>
			</p>
			<input type="submit" value="Converter" name="converter">
		</form>
	</body>
	<?php
		if (isset($_GET['converter'])) {
			//entrada de dados
			$valor=$_GET['valor'];
			$conversao = $_GET['conversao'];
			
			//processamento de dados
			switch ($conversao) {
				case 'cel':
					$resultado = round(($valor - 32) * 5/9,2);
					$txtUm = 'graus Farenheit';
					$txtDois = 'graus Celsius';
					break;
				case 'far':
					$resultado = round(9/5 * $valor + 32,2);
					$txtUm = 'graus Celsius';
					$txtDois = 'graus Farenheit';
					break;
			}
			
			//saída dos dados
			echo "$valor em $txtUm é igual a $resultado $txtDois";	
		}
	?>
</html>
