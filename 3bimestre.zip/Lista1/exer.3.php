
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>
    <h1>Exercício 001</h1>
    <form action="" method="GET">
    <p>Digite dois valores para mostrar as quatro operações básicas da matemática</p>
          <input type="text" name="vl1" placeholder="valor 1">
             <input type="text" name="vl2" placeholder="valor 2">
          <input type="submit" value="enviar" name="enviar">
    </form>
    <?php
    if(isset($_GET['enviar'])){
        $vl1= $_GET['vl1'];
        $vl2= $_GET['vl2'];
        $soma = round($vl1+$vl2);
        $sub= round($vl1-$vl2);
        $mult= round($vl1*$vl2);
        $div = round($vl1/$vl2);
        echo "a soma dos dois valores é $soma <br>";
        echo "A subtração dos dois valores é $sub <br>";
        echo "A multiplicação dos dois valores é $mult <br>";
        echo "A divisão dos dois valores é $div <br>";
    }else{}
    ?>
</body>
</html>
