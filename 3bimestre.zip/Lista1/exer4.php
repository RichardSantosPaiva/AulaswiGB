<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title> Exer 4</title>
</head>
<body>
    <h1>Exercício 04</h1>
    <form action="" method="GET">
    <p>Digite dois números, para descobrir quem é o dividendo, divisor, quociente, e resto</p>
          <input type="text" name="num1" placeholder="primeiro número">
          <input type="text" name="num2" placeholder="primeiro número">
          <input type="submit" name="enviar" value="enviar" >
    </form>
    <?php
        if(isset($_GET['enviar'])){
            $num1= $_GET['num1'];
            $num2 =$_GET['num2'];
            $quociente= $num1/$num2;
            $resto=$num1%$num2;
            echo "O dividendo é $num1 <br>";
            echo "O divisor é $num2 <br>";
            echo "O quociente é $quociente <br>";
            echo "O resto da divisão é $resto";
        }
    ?>
</body>
</html>
