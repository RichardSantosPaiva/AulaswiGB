<!DOCTYPE html>
<html lang = "pt-BR">
	<head>
		<title> Lista 1 - excel</title>
		<meta charse = "utf-8"/>
	</head>
	<body>
		<h1> Programa para conversão entre milímetro e polegada</h1>
			<h4> Lista 1 - Exercício 1</h4>
			<form action="" method="GET">
				<p>Informe im valor para ser convertido</br>
					<input type="text" name="valor">
				</p>
				<input type="submit" value="Conversão"  name="converter">
			</form>
		
	</body>
	<?php
		if (isset($_GET['converter'])){
		//entrada de dados
		$valor=$_GET['valor'];
		
		// processamento de dados
		$resultado = $valor/25.4;
		
		// saida de dados
		echo "$valor em milímetros é igual a $resultado polegadas";
		}
	?>
</html>