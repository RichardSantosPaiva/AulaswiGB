<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Exerc 5</title>
</head>
<body>
    <form action="" method="GET">
        <p>Digite por favor um determinado valor em segundo, exemplo: "2432"</p>
        <input type="text" name="vls" placeholder="valor segundos">
        <input type="submit" name="enviar" value="enviar">
    </form>
</body>
    <?php
        /*
         Exercício 5)Escreva um Programa em PHP quedado um determinado valor em segundos, indique na saída quanto esse valor representa em horas, minutos e segundos, sabendo que:
         1 hora = 3600segundos
         1 minuto = 60 segundos;

         Exemplo:se for informado 6543, o resultadoserá:
         -Horas: 1
         -Minutos: 49
         -Segundos: 3
         */
        if(isset($_GET['enviar'])){
            $vls = $_GET['vls'];
            $hr =(int)($vls/3600);
            $min =$vls/60;
            $seg = $vls;
            echo "O valor $vls em segundos, convertido em horas é : $hr <br>";
            echo "O valor $vls em segundos, convetido em minutos é $min <br>";
            echo "O valor em segudos é $seg";
        }

    ?>
</html>
