 
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>
    <h1>Exercício 001</h1>
    <form action="" method="GET">
    <p>Digite um valor em graus celcius para converter em farenhenit</p>
          <input type="text" name="cel" placeholder="Graus Celcius">
          <input type="submit" value="enviar" name="enviar">
    </form>
    <?php
    if(isset($_GET['enviar'])){
        $cel = $_GET['cel'];
        $faren = $cel*9/5+32;
        echo "<p> O valor $cel em graus celcius convertido em farenheint é $faren</p>";
    }else{}
    ?>
</body>
</html>
