<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    
     //criar um array de cidades
     $cidades = array (1=>"Barueri", "carapicuiba","Jandira","Itapevi","Cajamar");
    //tamanho do array     //1=> qr dizer 1 está aciossiado a barueri
    $tamanho = count($cidades);
    ?>
        <h3>Matriz unidimensional de cidades</h3>
        <h5>Lista 3 -Execel</h5>

        <form action="" method="GET">
            <p> Informe o indice da cidade:</br>
            <input type="text" name="indice"/></br></p>
            <input type="submit" name="pesquisar" value="Pesquisar"/>
        </form>
</body>
    <?php
        
        if (isset ($_GET['pesquisar'])) {
            $indice = $_GET['indice'];
            if ($indice <= $tamanho)
                echo " A cidade na posição <b> $indice</b> é: $cidades[$indice]";
            else
                echo "o índice $indice é  inválidado. Tente novamente!";
         }else {
            echo"aguardando entrada de dados!";
         }

    ?>

</html>